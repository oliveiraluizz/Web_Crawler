import java.util.ArrayList;
import java.util.List;

public class Filme {

    private String nome;
    private Double nota;
    private String moreInfoPath;
    private String moreInfoPath2;

    private List<String> diretores = new ArrayList<String>();
    private List<String> atores = new ArrayList<String>();
    private List<String> comentario = new ArrayList<String>();
    private List<String> notaComentario = new ArrayList<>();
    private List<String> originalName = new ArrayList<>();


    public Filme(String nome, Double nota) {
        this.nome = nome;
        this.nota = nota;
    }

    public Filme() {

    }

    public List<String> getDiretores() {
        return diretores;
    }

    public void setDiretores(List<String> diretores) {
        this.diretores = diretores;
    }
    public String getMoreInfoPath() {
        return moreInfoPath;
    }

    public void setMoreInfoPath(String moreInfoPath) {
        this.moreInfoPath = moreInfoPath;
    }

    public String getMoreInfoPath2() {
        return moreInfoPath2;
    }

    public void setMoreInfoPath2(String moreInfoPath2) {
        this.moreInfoPath2 = moreInfoPath2;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getNota() {
        return nota;
    }

    public void setNota(Double nota) {
        this.nota = nota;
    }

    public List<String> getAtores() {
        return atores;
    }

    public void setAtores(List<String> atores) {
        this.atores = atores;
    }

    public List<String> getComentario() {
        return comentario;
    }

    public void setComentario(List<String> comentario) {
        this.comentario = comentario;
    }

    public List<String> getNotaComentario() {
        return notaComentario;
    }

    public void setNotaComentario(List<String> notaComentario) {
        this.notaComentario = notaComentario;
    }

    public List<String> getOriginalName() {
        return originalName;
    }

    public void setOriginalName(List<String> originalName) {
        this.originalName = originalName;
    }
}
