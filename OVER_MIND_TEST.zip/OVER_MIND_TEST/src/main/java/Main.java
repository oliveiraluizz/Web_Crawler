import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class Main {

    static String url = "https://www.imdb.com/chart/bottom";

    public Main() throws IOException {
    }

    public static void main(String[] args) throws IOException {

        Document doc = Jsoup.connect(url).get();
        Element table = doc.getElementsByClass("chart full-width").first();
        Element tbody = table.getElementsByTag("tbody").first();
        List<Element> elements = tbody.getElementsByTag("tr");
        List<Filme> filmes = new ArrayList<Filme>();
        elements.forEach(e -> {
            List<Element> attributes = e.getElementsByTag("td");
            Element filmNameElement = attributes.get(1);
            Double nota = Double.parseDouble(attributes.get(2).text());
            String path = filmNameElement.getElementsByTag("a").first().attr("href");
            Filme filme = new Filme();
            filme.setMoreInfoPath(path);
            filme.setNome(filmNameElement.getElementsByTag("a").first().text());
            filme.setNota(nota);
            filmes.add(filme);
        });
        List<Filme> filmesFiltrados = filmes.stream().sorted(Comparator.comparing(e-> e.getNota())).limit(10).collect(Collectors.toList());
            filmesFiltrados.forEach(e->{
                try {
                    extractOriginalName(e.getMoreInfoPath(),e);

                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            try {
                extractDirector(e.getMoreInfoPath(),e);
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
                try {
                    extractAtores(e.getMoreInfoPath(),e);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    extractComentarios(e.getMoreInfoPath(),e);

                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
        });
        montarResultado(filmesFiltrados);
    }
    private static void montarResultado(List<Filme> filmesFiltrados) {
        for (int i = filmesFiltrados.size() - 1; i >= 0; i--) {
            System.out.println("Filme: " + filmesFiltrados.get(i).getNome());
            System.out.println("Nome Original: " + filmesFiltrados.get(i).getOriginalName().get(filmesFiltrados.get(i).getOriginalName().size()-1).toString().substring(16));
            filmesFiltrados.get(i).getOriginalName().stream()
                    .limit(filmesFiltrados.get(i).getOriginalName().size()-1)
                    .map(s -> s + ", ")
                    .forEach(System.out::print);
            System.out.println("Nota: " + filmesFiltrados.get(i).getNota());
            System.out.println("Diretores: " + filmesFiltrados.get(i).getDiretores().get(filmesFiltrados.get(i).getDiretores().size()-1));
            filmesFiltrados.get(i).getDiretores().stream()
                    .limit(filmesFiltrados.get(i).getDiretores().size()-1)
                    .map(s -> s + ", ")
                    .forEach(System.out::print);
            System.out.println("\nAtores: " +  filmesFiltrados.get(i).getAtores().get(filmesFiltrados.get(i).getAtores().size()-1));
            filmesFiltrados.get(i).getAtores().stream()
                    .limit(filmesFiltrados.get(i).getAtores().size()-1)
                    .map(s -> s + ", ")
                    .forEach(System.out::print);
            System.out.println("\nNotas dos comentarios: " + filmesFiltrados.get(i).getNotaComentario().stream()
                    .limit(filmesFiltrados.get(i).getNotaComentario().size()-1)
                    .filter(comentario->comentario.equals("10/10")).findFirst());
            System.out.println("Comentarios: " + filmesFiltrados.get(i).getComentario().get(0).toString());
            System.out.println("--------------------------------------------------------------");
        }
    }
    public static void extractOriginalName(String path, Filme filme) throws IOException {
        Document doc = Jsoup.connect("https://www.imdb.com/"+ path).get();
        List<Element> elements = new ArrayList<Element>();
        elements = doc.getElementsByClass("sc-dae4a1bc-0 gwBsXc");
        elements.forEach(e->{
                    filme.getOriginalName().add(e.text());
                }
        );
    }
    public static void extractDirector(String path, Filme filme) throws IOException {
        Document doc = Jsoup.connect("https://www.imdb.com/"+ path).get();
        List<Element> elements = new ArrayList<Element>();
        elements = doc.select("div:nth-child(1) > div > ul > li:nth-child(1) > div > ul > li > a");
        elements.forEach(e->{
                    filme.getDiretores().add(e.text());
                }
        );
    }
    public static void extractAtores(String path, Filme filme) throws IOException {
        Document doc = Jsoup.connect("https://www.imdb.com/"+ path).get();
        List<Element> elements = new ArrayList<Element>();
        elements = doc.select("div:nth-child(1) > div > ul > li:nth-child(3) > div > ul > li > a");
        elements.forEach(e->{
                    filme.getAtores().add(e.text());
                }
        );
    }
    public static void extractComentarios(String path, Filme filme) throws IOException {
        path = path.substring(0, 17);
        Document doc = Jsoup.connect("https://www.imdb.com/"+ path +"reviews?sort=userRating&dir=desc&ratingFilter=0").get();
        List<Element> elements = new ArrayList<Element>();
        List<Element> comments = new ArrayList<Element>();
        elements = doc.getElementsByClass("rating-other-user-rating");
        comments = doc.getElementsByClass("text show-more__control");
        elements.forEach(e->{
                    filme.getNotaComentario().add(e.text());
                }
        );
        comments.forEach(e->{

                    filme.getComentario().add(e.text());
                });

        Document docs = Jsoup.connect("https://www.imdb.com/title/tt1213644/?pf_rd_m=A2FGELUUNOQJNL&pf_rd_p=c28fd853-7526-417a-ad2b-02e76562a472&pf_rd_r=DKBH64P86ZN64VFBTT0F&pf_rd_s=center-1&pf_rd_t=15506&pf_rd_i=bottom&ref_=chtbtm_tt_1").get();

        Elements elementss = docs.getAllElements();

        try(BufferedWriter bw = new BufferedWriter(new FileWriter("D:\\User\\Documents\\temp\\tmp.txt"))){
            for(Element element: elementss) {
                bw.write(element.getAllElements().toString());
                bw.newLine();
            }
        }

    }

    public static void log(String message){
        System.out.println(message);
    }
}
